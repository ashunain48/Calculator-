document.addEventListener('DOMContentLoaded', () => {
    const fromUnit = document.getElementById('from-unit');
    const toUnit = document.getElementById('to-unit');
    const fromValue = document.getElementById('from-value');
    const resultValue = document.getElementById('result-value');

    // Conversion factors to a base unit (gram)
    const toGrams = {
        gram: 1,
        kilogram: 1000,
        milligram: 0.001,
        pound: 453.592,
        ounce: 28.3495
    };

    function convertMass() {
        const from = fromUnit.value;
        const to = toUnit.value;
        const value = parseFloat(fromValue.value);

        if (isNaN(value)) {
            resultValue.textContent = '-';
            return;
        }

        const valueInGrams = value * toGrams[from];
        const result = valueInGrams / toGrams[to];

        resultValue.textContent = result.toLocaleString();
    }

    fromUnit.addEventListener('change', convertMass);
    toUnit.addEventListener('change', convertMass);
    fromValue.addEventListener('input', convertMass);
});