document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const fromUnitSelect = document.getElementById('from-unit');
    const fromValueInput = document.getElementById('from-value');
    const toUnitSelect = document.getElementById('to-unit');
    const resultValueElement = document.getElementById('result-value');

    // Define conversion factors relative to the base unit, Kilogram/Liter.
    // These terms are multipliers of a "Ser". We assume 1 Ser = 1 Kg/L.
    const conversionFactors = {
        ser: 1,
        pona: 0.75,     // पौणा (Pona) = Three-quarters
        sava: 1.25,     // सवा (Sava) = One and a quarter
        dyod: 1.5,      // ड्योढ़ (Dyod) = One and a half
        dhai: 2.5,      // ढाई (Dhai) = Two and a half
        kilogram: 1,
        liter: 1,
    };

    // Array for populating dropdowns with Haryanvi and English names
    const units = [
        { value: 'dhai', text: 'ढाई सेर (Dhai Ser - 2.5)' },
        { value: 'dyod', text: 'ड्योढ़ सेर (Dyod Ser - 1.5)' },
        { value: 'sava', text: 'सवा सेर (Sava Ser - 1.25)' },
        { value: 'pona', text: 'पौणा सेर (Pona Ser - 0.75)' },
        { value: 'ser', text: 'सेर (Ser - 1)' },
        { value: 'kilogram', text: 'किलोग्राम (Kilogram)' },
        { value: 'liter', text: 'लीटर (Liter)' },
    ];

    function populateDropdowns() {
        units.forEach(unit => {
            const option1 = new Option(unit.text, unit.value);
            const option2 = new Option(unit.text, unit.value);
            fromUnitSelect.add(option1);
            toUnitSelect.add(option2);
        });
        // Set some sensible defaults
        fromUnitSelect.value = 'dhai';
        toUnitSelect.value = 'kilogram';
    }

    const convertLiquid = () => {
        const fromValue = parseFloat(fromValueInput.value);
        const fromUnit = fromUnitSelect.value;
        const toUnit = toUnitSelect.value;

        if (isNaN(fromValue)) {
            resultValueElement.textContent = '-';
            return;
        }

        // Step 1: Convert the input quantity to the base unit (Kg/L)
        const valueInBase = fromValue * conversionFactors[fromUnit];

        // Step 2: Convert from the base unit to the target quantity
        const result = valueInBase / conversionFactors[toUnit];

        // Format the result
        resultValueElement.textContent = `${parseFloat(result.toFixed(4))} (in ${toUnitSelect.options[toUnitSelect.selectedIndex].text})`;
    };

    // Add event listeners to all interactive elements
    fromUnitSelect.addEventListener('change', convertLiquid);
    fromValueInput.addEventListener('input', convertLiquid);
    toUnitSelect.addEventListener('change', convertLiquid);

    // Initial setup
    populateDropdowns();
    convertLiquid();
});