document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const cpuInput = document.getElementById('cpu-watts');
    const gpuInput = document.getElementById('gpu-watts');
    const otherInput = document.getElementById('other-watts');
    const loadWattageResult = document.getElementById('load-wattage');
    const recommendedWattageResult = document.getElementById('recommended-wattage');

    const calculatePSU = () => {
        const cpuWatts = parseFloat(cpuInput.value) || 0;
        const gpuWatts = parseFloat(gpuInput.value) || 0;
        const otherWatts = parseFloat(otherInput.value) || 0;

        const totalLoad = cpuWatts + gpuWatts + otherWatts;

        if (totalLoad === 0) {
            loadWattageResult.textContent = '- W';
            recommendedWattageResult.textContent = '- W';
            return;
        }

        // Recommended PSU: Total load + 25% headroom, rounded up to the nearest 50W.
        // PSUs are typically sold in increments of 50W (e.g., 550W, 600W, 650W).
        const recommended = Math.ceil((totalLoad * 1.25) / 50) * 50;
        
        loadWattageResult.textContent = `${totalLoad} W`;
        recommendedWattageResult.textContent = `${recommended} W`;
    };

    // Add event listeners to all input fields
    [cpuInput, gpuInput, otherInput].forEach(input => {
        input.addEventListener('input', calculatePSU);
    });

    // Initial calculation
    calculatePSU();
});