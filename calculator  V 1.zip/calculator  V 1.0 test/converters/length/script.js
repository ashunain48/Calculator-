document.addEventListener('DOMContentLoaded', () => {
    const fromUnit = document.getElementById('from-unit');
    const toUnit = document.getElementById('to-unit');
    const fromValue = document.getElementById('from-value');
    const resultValue = document.getElementById('result-value');

    // Conversion factors to a base unit (meter)
    const toMeters = {
        meter: 1,
        kilometer: 1000,
        centimeter: 0.01,
        millimeter: 0.001,
        mile: 1609.34,
        yard: 0.9144,
        foot: 0.3048,
        inch: 0.0254
    };

    function convertLength() {
        const from = fromUnit.value;
        const to = toUnit.value;
        const value = parseFloat(fromValue.value);

        if (isNaN(value)) {
            resultValue.textContent = '-';
            return;
        }

        // Step 1: Convert input value to the base unit (meters)
        const valueInMeters = value * toMeters[from];

        // Step 2: Convert from base unit to the target unit
        const result = valueInMeters / toMeters[to];

        resultValue.textContent = result.toLocaleString();
    }

    fromUnit.addEventListener('change', convertLength);
    toUnit.addEventListener('change', convertLength);
    fromValue.addEventListener('input', convertLength);
});