document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const fromUnitSelect = document.getElementById('from-unit');
    const fromValueInput = document.getElementById('from-value');
    const toUnitSelect = document.getElementById('to-unit');
    const resultValueElement = document.getElementById('result-value');

    // Define conversion factors relative to the base unit, Gaj (Square Yard)
    // 1 Killa = 1 Ekar (Acre)
    // 1 Acre = 4840 Square Yards (Gaj)
    // We will use a standard Bigha measurement, common in Haryana/Punjab.
    // 1 Bigha = 1600 Square Yards (Gaj). Note: This can vary by region.
    const conversionFactors = {
        gaj: 1,
        bigha: 1600,
        ekar: 4840,
    };

    const convertArea = () => {
        const fromValue = parseFloat(fromValueInput.value);
        const fromUnit = fromUnitSelect.value;
        const toUnit = toUnitSelect.value;

        if (isNaN(fromValue)) {
            resultValueElement.textContent = '-';
            return;
        }

        // Step 1: Convert the input value to the base unit (Gaj)
        const valueInGaj = fromValue * conversionFactors[fromUnit];

        // Step 2: Convert from the base unit to the target unit
        const result = valueInGaj / conversionFactors[toUnit];

        // Format the result to a reasonable number of decimal places
        resultValueElement.textContent = parseFloat(result.toFixed(6));
    };

    // Add event listeners to all interactive elements
    fromUnitSelect.addEventListener('change', convertArea);
    fromValueInput.addEventListener('input', convertArea);
    toUnitSelect.addEventListener('change', convertArea);

    // Initial calculation for any autofilled values
    convertArea();
});