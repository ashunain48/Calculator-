document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const fromUnitSelect = document.getElementById('from-unit');
    const fromValueInput = document.getElementById('from-value');
    const toUnitSelect = document.getElementById('to-unit');
    const resultValueElement = document.getElementById('result-value');
    const resultScientificElement = document.getElementById('result-value-scientific');

    // Use BigInt for all conversion factors to handle massive numbers accurately.
    const conversionFactors = {
        bit: 1n, byte: 8n, kilobyte: 8n * 1024n, megabyte: 8n * 1024n ** 2n,
        gigabyte: 8n * 1024n ** 3n, terabyte: 8n * 1024n ** 4n, petabyte: 8n * 1024n ** 5n,
        exabyte: 8n * 1024n ** 6n, zettabyte: 8n * 1024n ** 7n, yottabyte: 8n * 1024n ** 8n,
        brontobyte: 8n * 1024n ** 9n, geopbyte: 8n * 1024n ** 10n,
    };

    const units = [
        { value: 'bit', text: 'Bit (b)' }, { value: 'byte', text: 'Byte (B)' },
        { value: 'kilobyte', text: 'Kilobyte (KB)' }, { value: 'megabyte', text: 'Megabyte (MB)' },
        { value: 'gigabyte', text: 'Gigabyte (GB)' }, { value: 'terabyte', text: 'Terabyte (TB)' },
        { value: 'petabyte', text: 'Petabyte (PB)' }, { value: 'exabyte', text: 'Exabyte (EB)' },
        { value: 'zettabyte', text: 'Zettabyte (ZB)' }, { value: 'yottabyte', text: 'Yottabyte (YB)' },
        { value: 'brontobyte', text: 'Brontobyte (BB)' }, { value: 'geopbyte', text: 'Geopbyte (GeB)' },
    ];

    function populateDropdowns() {
        units.forEach(unit => {
            fromUnitSelect.add(new Option(unit.text, unit.value));
            toUnitSelect.add(new Option(unit.text, unit.value));
        });
        fromUnitSelect.value = 'gigabyte';
        toUnitSelect.value = 'megabyte';
    }

    // Function to format BigInt division into a decimal string
    function formatResult(bigIntResult, divisor) {
        const precision = 100n;
        const integerPart = bigIntResult / divisor;
        const fractionalPart = (bigIntResult * precision / divisor) % precision;
        if (fractionalPart === 0n) return integerPart.toString();
        let fractionalString = fractionalPart.toString().padStart(precision.toString().length - 1, '0').replace(/0+$/, '');
        return `${integerPart}.${fractionalString}`;
    }
    
    // NEW function to format a number string into scientific notation
    function toScientificNotation(numStr) {
        if (!numStr || isNaN(numStr[0])) return '';

        // Use JavaScript's built-in functionality for numbers within its safe range
        const num = Number(numStr);
        if (Math.abs(num) < 1e21 && num !== 0) {
            return num.toExponential(6).replace(/e\+?/, ' x 10^');
        }

        // Manual string manipulation for numbers too large for Number type
        let [integer, fraction = ''] = numStr.split('.');
        integer = integer.replace(/^-/, ''); // Handle negative numbers
        
        let exponent;
        let mantissa;

        if (integer !== '0') {
            exponent = integer.length - 1;
            const allDigits = integer + fraction;
            mantissa = `${allDigits[0]}.${allDigits.substring(1)}`;
        } else {
            const firstNonZeroIndex = fraction.search(/[1-9]/);
            if (firstNonZeroIndex === -1) return '0'; // It's just zero
            exponent = -(firstNonZeroIndex + 1);
            const significantDigits = fraction.substring(firstNonZeroIndex);
            mantissa = `${significantDigits[0]}.${significantDigits.substring(1)}`;
        }
        
        mantissa = parseFloat(mantissa).toFixed(6);
        return `${numStr.startsWith('-') ? '-' : ''}${mantissa} x 10^${exponent}`;
    }


    const convertData = () => {
        const fromValueStr = fromValueInput.value;
        const fromUnit = fromUnitSelect.value;
        const toUnit = toUnitSelect.value;

        if (fromValueStr === '' || isNaN(parseFloat(fromValueStr))) {
            resultValueElement.textContent = '-';
            resultScientificElement.textContent = ''; // Clear scientific notation too
            return;
        }

        try {
            const [integer, fraction = ''] = fromValueStr.split('.');
            const precision = 10n ** BigInt(fraction.length);
            const fromValueBigInt = BigInt(integer) * precision + BigInt(fraction);
            const valueInBits = fromValueBigInt * conversionFactors[fromUnit];
            const divisor = conversionFactors[toUnit] * precision;
            
            const resultString = formatResult(valueInBits, divisor);
            resultValueElement.textContent = resultString;
            
            // Only show scientific notation for very large or small numbers
            if (resultString.includes('.') && resultString.startsWith('0.0000')) {
                 resultScientificElement.textContent = toScientificNotation(resultString);
            } else if (!resultString.includes('.') && resultString.length > 12) {
                 resultScientificElement.textContent = toScientificNotation(resultString);
            } else {
                 resultScientificElement.textContent = '';
            }

        } catch (error) {
            console.error(error);
            resultValueElement.textContent = 'Error';
            resultScientificElement.textContent = '';
        }
    };

    [fromUnitSelect, fromValueInput, toUnitSelect].forEach(element => {
        element.addEventListener('input', convertData);
    });

    populateDropdowns();
    convertData();
});