document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const fromUnitSelect = document.getElementById('from-unit');
    const fromValueInput = document.getElementById('from-value');
    const toUnitSelect = document.getElementById('to-unit');
    const resultValueElement = document.getElementById('result-value');

    // Define conversion factors relative to the base unit, Kilogram.
    const conversionFactors = {
        kilogram: 1,
        ser: 1,       // 1 सेर (Ser) approximated as 1 Kg
        dedhi: 1.5,   // 1 देढ़ी (Dedhi) = 1.5 Ser
        dhadi: 5,     // 1 धड़ी (Dhadi) = 5 Ser
        maund: 40,    // 1 मण (Maund) = 40 Ser
        quintal: 100  // 1 क्विंटल (Quintal) = 100 Kg
    };

    // Array for populating dropdowns with Haryanvi and English names
    const units = [
        { value: 'maund', text: 'मण (Maund)' },
        { value: 'quintal', text: 'क्विंटल (Quintal)' },
        { value: 'dhadi', text: 'धड़ी (Dhadi)' },
        { value: 'ser', text: 'सेर (Ser)' },
        { value: 'dedhi', text: 'देढ़ी (Dedhi)' },
        { value: 'kilogram', text: 'किलोग्राम (Kilogram)' },
    ];

    function populateDropdowns() {
        units.forEach(unit => {
            const option1 = new Option(unit.text, unit.value);
            const option2 = new Option(unit.text, unit.value);
            fromUnitSelect.add(option1);
            toUnitSelect.add(option2);
        });
        // Set some sensible defaults
        fromUnitSelect.value = 'maund';
        toUnitSelect.value = 'quintal';
    }

    const convertWeight = () => {
        const fromValue = parseFloat(fromValueInput.value);
        const fromUnit = fromUnitSelect.value;
        const toUnit = toUnitSelect.value;

        if (isNaN(fromValue)) {
            resultValueElement.textContent = '-';
            return;
        }

        // Step 1: Convert the input value to the base unit (Kilograms)
        const valueInKg = fromValue * conversionFactors[fromUnit];

        // Step 2: Convert from the base unit to the target unit
        const result = valueInKg / conversionFactors[toUnit];

        // Format the result to a reasonable number of decimal places
        resultValueElement.textContent = parseFloat(result.toFixed(4));
    };

    // Add event listeners to all interactive elements
    fromUnitSelect.addEventListener('change', convertWeight);
    fromValueInput.addEventListener('input', convertWeight);
    toUnitSelect.addEventListener('change', convertWeight);

    // Initial setup
    populateDropdowns();
    convertWeight();
});