document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const calcRadios = document.querySelectorAll('input[name="calculate"]');
    const voltageInput = document.getElementById('voltage-input');
    const currentInput = document.getElementById('current-input');
    const powerInput = document.getElementById('power-input');

    let calculationMode = 'voltage'; // Default mode

    // Function to update the UI based on the selected calculation mode
    const updateUI = () => {
        // Reset all inputs first
        voltageInput.readOnly = false;
        currentInput.readOnly = false;
        powerInput.readOnly = false;
        
        voltageInput.placeholder = 'Enter voltage';
        currentInput.placeholder = 'Enter current';
        powerInput.placeholder = 'Enter power';

        // Set the result field to readonly and update placeholders
        if (calculationMode === 'voltage') {
            voltageInput.readOnly = true;
            voltageInput.placeholder = 'Result';
        } else if (calculationMode === 'current') {
            currentInput.readOnly = true;
            currentInput.placeholder = 'Result';
        } else if (calculationMode === 'power') {
            powerInput.readOnly = true;
            powerInput.placeholder = 'Result';
        }
        
        // Clear all values on mode change
        voltageInput.value = '';
        currentInput.value = '';
        powerInput.value = '';
    };

    // Main calculation function
    const calculate = () => {
        const voltage = parseFloat(voltageInput.value);
        const current = parseFloat(currentInput.value);
        const power = parseFloat(powerInput.value);

        if (calculationMode === 'voltage') {
            if (!isNaN(power) && !isNaN(current) && current !== 0) {
                const result = power / current;
                voltageInput.value = parseFloat(result.toFixed(4));
            } else {
                voltageInput.value = '';
            }
        } else if (calculationMode === 'current') {
            if (!isNaN(power) && !isNaN(voltage) && voltage !== 0) {
                const result = power / voltage;
                currentInput.value = parseFloat(result.toFixed(4));
            } else {
                currentInput.value = '';
            }
        } else if (calculationMode === 'power') {
            if (!isNaN(voltage) && !isNaN(current)) {
                const result = voltage * current;
                powerInput.value = parseFloat(result.toFixed(4));
            } else {
                powerInput.value = '';
            }
        }
    };

    // Event Listeners
    calcRadios.forEach(radio => {
        radio.addEventListener('change', (e) => {
            calculationMode = e.target.value;
            updateUI();
        });
    });

    [voltageInput, currentInput, powerInput].forEach(input => {
        input.addEventListener('input', calculate);
    });

    // Initial setup
    updateUI();
});