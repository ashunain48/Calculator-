document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const conversionTypeSelect = document.getElementById('conversion-type');
    const fromUnitSelect = document.getElementById('from-unit');
    const toUnitSelect = document.getElementById('to-unit');
    const fromValueInput = document.getElementById('from-value');
    const resultValueElement = document.getElementById('result-value');

    // Data object for units, options, and conversion factors
    const unitsData = {
        voltage: {
            factors: {
                volt: 1, kilovolt: 1000, megavolt: 1000000,
                millivolt: 0.001, microvolt: 0.000001
            },
            options: [
                { value: 'volt', text: 'Volt (V)' },
                { value: 'kilovolt', text: 'Kilovolt (kV)' },
                { value: 'megavolt', text: 'Megavolt (MV)' },
                { value: 'millivolt', text: 'Millivolt (mV)' },
                { value: 'microvolt', text: 'Microvolt (µV)' }
            ],
            defaultTo: 'millivolt'
        },
        current: {
            factors: {
                ampere: 1, kiloampere: 1000,
                milliampere: 0.001, microampere: 0.000001
            },
            options: [
                { value: 'ampere', text: 'Ampere (A)' },
                { value: 'kiloampere', text: 'Kiloampere (kA)' },
                { value: 'milliampere', text: 'Milliampere (mA)' },
                { value: 'microampere', text: 'Microampere (µA)' }
            ],
            defaultTo: 'milliampere'
        }
    };

    // Function to populate "From" and "To" dropdowns based on the selected quantity
    const populateUnitDropdowns = () => {
        const selectedType = conversionTypeSelect.value;
        const typeData = unitsData[selectedType];

        // Clear existing options
        fromUnitSelect.innerHTML = '';
        toUnitSelect.innerHTML = '';

        // Populate with new options
        typeData.options.forEach(option => {
            fromUnitSelect.add(new Option(option.text, option.value));
            toUnitSelect.add(new Option(option.text, option.value));
        });

        // Set default selections
        toUnitSelect.value = typeData.defaultTo;
        
        // Trigger a new calculation
        convert();
    };

    // Main conversion function
    const convert = () => {
        const selectedType = conversionTypeSelect.value;
        const factors = unitsData[selectedType].factors;
        
        const fromValue = parseFloat(fromValueInput.value);
        const fromUnit = fromUnitSelect.value;
        const toUnit = toUnitSelect.value;

        if (isNaN(fromValue) || !fromUnit || !toUnit) {
            resultValueElement.textContent = '-';
            return;
        }

        const valueInBaseUnit = fromValue * factors[fromUnit];
        const result = valueInBaseUnit / factors[toUnit];

        resultValueElement.textContent = parseFloat(result.toPrecision(8));
    };

    // Event Listeners
    conversionTypeSelect.addEventListener('change', populateUnitDropdowns);
    fromValueInput.addEventListener('input', convert);
    fromUnitSelect.addEventListener('change', convert);
    toUnitSelect.addEventListener('change', convert);

    // Initial setup on page load
    populateUnitDropdowns();
});