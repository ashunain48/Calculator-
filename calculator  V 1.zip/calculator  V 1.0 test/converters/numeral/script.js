document.addEventListener('DOMContentLoaded', () => {
    const fromBaseSelect = document.getElementById('from-base');
    const toBaseSelect = document.getElementById('to-base');
    const fromValueInput = document.getElementById('from-value');
    const resultValue = document.getElementById('result-value');

    function convertNumeral() {
        const fromBase = parseInt(fromBaseSelect.value);
        const toBase = parseInt(toBaseSelect.value);
        const value = fromValueInput.value.trim();

        if (value === '') {
            resultValue.textContent = '-';
            return;
        }

        try {
            // Step 1: Convert the input string from its original base to a standard decimal (base-10) number.
            const decimalValue = parseInt(value, fromBase);

            // Check if the input was valid for the given base
            if (isNaN(decimalValue)) {
                throw new Error('Invalid input for base');
            }

            // Step 2: Convert the decimal number to the target base string.
            const result = decimalValue.toString(toBase).toUpperCase();
            
            resultValue.textContent = result;

        } catch (error) {
            resultValue.textContent = 'Error';
        }
    }

    fromBaseSelect.addEventListener('change', convertNumeral);
    toBaseSelect.addEventListener('change', convertNumeral);
    fromValueInput.addEventListener('input', convertNumeral);
});