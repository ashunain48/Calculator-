document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const voltageInput = document.getElementById('voltage-input');
    const currentInput = document.getElementById('current-input');
    const powerOutput = document.getElementById('power-output');

    const calculatePower = () => {
        const voltage = parseFloat(voltageInput.value) || 0;
        const current = parseFloat(currentInput.value) || 0;

        // If either input is missing, show placeholder
        if (voltage === 0 || current === 0) {
            powerOutput.textContent = '- W';
            return;
        }

        const power = voltage * current;
        
        // Display result, removing unnecessary trailing zeros if they exist
        powerOutput.textContent = `${parseFloat(power.toFixed(2))} W`;
    };

    // Add event listeners to both input fields
    [voltageInput, currentInput].forEach(input => {
        input.addEventListener('input', calculatePower);
    });

    // Initial calculation for any autofilled values
    calculatePower();
});