document.addEventListener('DOMContentLoaded', () => {
    const fromUnit = document.getElementById('from-unit');
    const toUnit = document.getElementById('to-unit');
    const fromValue = document.getElementById('from-value');
    const resultValue = document.getElementById('result-value');

    const toSquareMeters = {
        square_meter: 1,
        square_kilometer: 1000000,
        square_mile: 2589988.11,
        hectare: 10000,
        acre: 4046.86
    };

    function convertArea() {
        const from = fromUnit.value;
        const to = toUnit.value;
        const value = parseFloat(fromValue.value);

        if (isNaN(value)) {
            resultValue.textContent = '-';
            return;
        }
        
        const valueInSquareMeters = value * toSquareMeters[from];
        const result = valueInSquareMeters / toSquareMeters[to];
        
        resultValue.textContent = result.toLocaleString();
    }

    fromUnit.addEventListener('change', convertArea);
    toUnit.addEventListener('change', convertArea);
    fromValue.addEventListener('input', convertArea);
});