document.addEventListener('DOMContentLoaded', () => {
    const birthDateInput = document.getElementById('birth-date');
    const resultValue = document.getElementById('result-value');
    const nextBdayValue = document.getElementById('next-birthday-value');

    function calculateAge() {
        const birthDate = new Date(birthDateInput.value);
        const today = new Date();

        if (isNaN(birthDate.getTime()) || birthDate > today) {
            resultValue.textContent = '-';
            nextBdayValue.textContent = '-';
            return;
        }

        let years = today.getFullYear() - birthDate.getFullYear();
        let months = today.getMonth() - birthDate.getMonth();
        let days = today.getDate() - birthDate.getDate();

        if (days < 0) {
            months--;
            days += new Date(today.getFullYear(), today.getMonth(), 0).getDate();
        }

        if (months < 0) {
            years--;
            months += 12;
        }

        resultValue.textContent = `${years} years, ${months} months, ${days} days`;
        
        // Calculate next birthday
        let nextBirthday = new Date(today.getFullYear(), birthDate.getMonth(), birthDate.getDate());
        if (today > nextBirthday) {
            nextBirthday.setFullYear(today.getFullYear() + 1);
        }
        
        const timeDiff = nextBirthday.getTime() - today.getTime();
        const daysToNextBday = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
        nextBdayValue.textContent = `${daysToNextBday} days away`;

    }

    birthDateInput.addEventListener('input', calculateAge);
});