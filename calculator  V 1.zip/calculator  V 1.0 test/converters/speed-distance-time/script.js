document.addEventListener('DOMContentLoaded', () => {
    // Get all necessary elements from the DOM
    const calculateRadios = document.querySelectorAll('input[name="calculate"]');
    const labelA = document.getElementById('label-a');
    const labelB = document.getElementById('label-b');
    const inputA = document.getElementById('input-a');
    const inputB = document.getElementById('input-b');
    const unitA = document.getElementById('unit-a');
    const unitB = document.getElementById('unit-b');
    const resultLabel = document.getElementById('result-label');
    const resultValue = document.getElementById('result-value');

    // Define the units for each measurement type
    const units = {
        distance: `
            <option value="km">Kilometers</option>
            <option value="m">Meters</option>
            <option value="mi">Miles</option>
        `,
        time: `
            <option value="hr">Hours</option>
            <option value="min">Minutes</option>
            <option value="sec">Seconds</option>
        `,
        speed: `
            <option value="kph">km/h</option>
            <option value="mps">m/s</option>
            <option value="mph">mph</option>
        `
    };

    // Define conversion factors to a base unit
    const toBase = {
        // Distance base: meters
        m: 1, km: 1000, mi: 1609.34,
        // Time base: seconds
        sec: 1, min: 60, hr: 3600,
        // Speed base: m/s
        mps: 1, kph: 0.277778, mph: 0.44704,
    };

    // Function to update the UI based on what the user wants to calculate
    function updateUI() {
        const selectedValue = document.querySelector('input[name="calculate"]:checked').value;

        if (selectedValue === 'speed') {
            labelA.textContent = 'Distance';
            unitA.innerHTML = units.distance;
            labelB.textContent = 'Time';
            unitB.innerHTML = units.time;
            resultLabel.textContent = 'Speed';
        } else if (selectedValue === 'distance') {
            labelA.textContent = 'Speed';
            unitA.innerHTML = units.speed;
            labelB.textContent = 'Time';
            unitB.innerHTML = units.time;
            resultLabel.textContent = 'Distance';
        } else { // time
            labelA.textContent = 'Distance';
            unitA.innerHTML = units.distance;
            labelB.textContent = 'Speed';
            unitB.innerHTML = units.speed;
            resultLabel.textContent = 'Time';
        }
        calculate();
    }

    // Main calculation function
    function calculate() {
        const selectedValue = document.querySelector('input[name="calculate"]:checked').value;
        const valA = parseFloat(inputA.value);
        const valB = parseFloat(inputB.value);

        if (isNaN(valA) || isNaN(valB) || valA <= 0 || valB <= 0) {
            resultValue.textContent = '-';
            return;
        }

        const unitTypeA = unitA.value;
        const unitTypeB = unitB.value;
        
        // Convert inputs to base units (m, s, m/s)
        const baseValA = valA * toBase[unitTypeA];
        const baseValB = valB * toBase[unitTypeB];

        let resultBase, resultText;

        if (selectedValue === 'speed') { // Result in m/s
            resultBase = baseValA / baseValB;
            resultText = `${(resultBase / toBase.kph).toFixed(2)} km/h`;
        } else if (selectedValue === 'distance') { // Result in meters
            resultBase = baseValA * baseValB;
            resultText = `${(resultBase / toBase.km).toFixed(2)} km`;
        } else { // time, result in seconds
            resultBase = baseValA / baseValB;
            const hours = Math.floor(resultBase / 3600);
            const minutes = Math.floor((resultBase % 3600) / 60);
            const seconds = Math.round(resultBase % 60);
            resultText = `${hours}h ${minutes}m ${seconds}s`;
        }
        
        resultValue.textContent = resultText;
    }
    
    // Add event listeners
    calculateRadios.forEach(radio => radio.addEventListener('change', updateUI));
    [inputA, inputB, unitA, unitB].forEach(el => el.addEventListener('input', calculate));
    [unitA, unitB].forEach(el => el.addEventListener('change', calculate));


    // Initialize the UI on page load
    updateUI();
});