document.addEventListener('DOMContentLoaded', () => {
    const priceInput = document.getElementById('original-price');
    const discountInput = document.getElementById('discount-percent');
    const finalPriceDisplay = document.getElementById('final-price');
    const savedAmountDisplay = document.getElementById('saved-amount');

    function calculateDiscount() {
        const price = parseFloat(priceInput.value);
        const discount = parseFloat(discountInput.value);

        if (isNaN(price) || isNaN(discount) || price < 0 || discount < 0) {
            finalPriceDisplay.textContent = '-';
            savedAmountDisplay.textContent = '-';
            return;
        }

        const savedAmount = price * (discount / 100);
        const finalPrice = price - savedAmount;

        finalPriceDisplay.textContent = finalPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        savedAmountDisplay.textContent = savedAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    priceInput.addEventListener('input', calculateDiscount);
    discountInput.addEventListener('input', calculateDiscount);
});