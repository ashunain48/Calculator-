document.addEventListener('DOMContentLoaded', () => {
    const textInput = document.getElementById('text-input');
    const bitsResult = document.getElementById('bits-result');
    const bytesResult = document.getElementById('bytes-result');
    const kbResult = document.getElementById('kb-result');
    const mbResult = document.getElementById('mb-result');

    const calculateSize = () => {
        const text = textInput.value;
        
        // Using TextEncoder is more accurate for UTF-8 characters than .length
        const encoder = new TextEncoder();
        const bytes = encoder.encode(text).length;
        
        const bits = bytes * 8;
        const kilobytes = bytes / 1024;
        const megabytes = kilobytes / 1024;

        bitsResult.textContent = bits.toLocaleString();
        bytesResult.textContent = bytes.toLocaleString();
        kbResult.textContent = parseFloat(kilobytes.toFixed(6));
        mbResult.textContent = parseFloat(megabytes.toFixed(6));
    };

    textInput.addEventListener('input', calculateSize);

    // Initial calculation
    calculateSize();
});