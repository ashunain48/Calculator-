document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const calcRadios = document.querySelectorAll('input[name="calculate"]');
    const rpmInput = document.getElementById('rpm-input');
    const timeInput = document.getElementById('time-input');

    let calculationMode = 'time'; // Default: Calculate Time from RPM

    // Function to update the UI based on the selected calculation mode
    const updateUI = () => {
        // Reset both fields to be editable
        rpmInput.readOnly = false;
        timeInput.readOnly = false;
        
        // Update placeholders
        rpmInput.placeholder = 'Enter RPM';
        timeInput.placeholder = 'Enter time in seconds';

        // Set the result field to readonly and update its placeholder
        if (calculationMode === 'time') {
            timeInput.readOnly = true;
            timeInput.placeholder = 'Result in seconds';
        } else { // calculationMode === 'rpm'
            rpmInput.readOnly = true;
            rpmInput.placeholder = 'Result in RPM';
        }
        
        // Clear both values when the mode changes
        rpmInput.value = '';
        timeInput.value = '';
    };

    // Main calculation function
    const calculate = () => {
        if (calculationMode === 'time') {
            const rpm = parseFloat(rpmInput.value);
            if (!isNaN(rpm) && rpm > 0) {
                const result = 60 / rpm;
                timeInput.value = parseFloat(result.toPrecision(6));
            } else {
                timeInput.value = '';
            }
        } else { // calculationMode === 'rpm'
            const time = parseFloat(timeInput.value);
            if (!isNaN(time) && time > 0) {
                const result = 60 / time;
                rpmInput.value = parseFloat(result.toPrecision(6));
            } else {
                rpmInput.value = '';
            }
        }
    };

    // Event Listeners
    calcRadios.forEach(radio => {
        radio.addEventListener('change', (e) => {
            calculationMode = e.target.value;
            updateUI();
        });
    });

    // Add input listeners to both fields
    rpmInput.addEventListener('input', calculate);
    timeInput.addEventListener('input', calculate);

    // Initial setup
    updateUI();
});