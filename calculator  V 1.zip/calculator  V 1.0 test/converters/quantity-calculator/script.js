document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const initialInput = document.getElementById('initial-quantity');
    const changeInput = document.getElementById('change-quantity');
    const operationRadios = document.querySelectorAll('input[name="operation"]');
    const finalQuantityResult = document.getElementById('final-quantity');

    const calculateQuantity = () => {
        const initial = parseFloat(initialInput.value) || 0;
        const change = parseFloat(changeInput.value) || 0;
        const operation = document.querySelector('input[name="operation"]:checked').value;

        let finalQuantity;

        if (operation === 'add') {
            finalQuantity = initial + change;
        } else { // operation === 'subtract'
            finalQuantity = initial - change;
        }
        
        // Display the result. Use toLocaleString() to format large numbers with commas.
        finalQuantityResult.textContent = finalQuantity.toLocaleString();
    };

    // Add event listeners to all inputs and radio buttons
    [initialInput, changeInput].forEach(input => {
        input.addEventListener('input', calculateQuantity);
    });

    operationRadios.forEach(radio => {
        radio.addEventListener('change', calculateQuantity);
    });

    // Initial calculation for any autofilled values
    calculateQuantity();
});