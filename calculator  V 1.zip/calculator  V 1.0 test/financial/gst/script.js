document.addEventListener('DOMContentLoaded', () => {
    const amountInput = document.getElementById('amount');
    const rateInput = document.getElementById('gst-rate');
    const typeRadios = document.querySelectorAll('input[name="gst-type"]');
    const netDisplay = document.getElementById('net-amount');
    const gstDisplay = document.getElementById('gst-amount');
    const totalDisplay = document.getElementById('total-amount');

    function calculateGST() {
        const amount = parseFloat(amountInput.value);
        const rate = parseFloat(rateInput.value);
        const type = document.querySelector('input[name="gst-type"]:checked').value;

        if (isNaN(amount) || isNaN(rate)) {
            netDisplay.textContent = '-';
            gstDisplay.textContent = '-';
            totalDisplay.textContent = '-';
            return;
        }

        let net, gst, total;

        if (type === 'add') {
            net = amount;
            gst = net * (rate / 100);
            total = net + gst;
        } else { // remove
            total = amount;
            net = total / (1 + (rate / 100));
            gst = total - net;
        }
        
        netDisplay.textContent = net.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        gstDisplay.textContent = gst.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        totalDisplay.textContent = total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    amountInput.addEventListener('input', calculateGST);
    rateInput.addEventListener('input', calculateGST);
    typeRadios.forEach(radio => radio.addEventListener('change', calculateGST));
});