document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const rateInput = document.getElementById('rate');
    const weightValueInput = document.getElementById('weight-value');
    const weightUnitSelect = document.getElementById('weight-unit');
    const totalPriceElement = document.getElementById('total-price');

    // Define conversion factors to convert all units to Kilograms
    const unitsToKg = {
        gram: 0.001,
        kilogram: 1,
        ser: 1,      // Approximating 1 Ser = 1 Kg
        dhadi: 5,    // 1 Dhadi = 5 Ser = 5 Kg
    };

    const calculatePrice = () => {
        const ratePerKg = parseFloat(rateInput.value);
        const weightValue = parseFloat(weightValueInput.value);
        const weightUnit = weightUnitSelect.value;

        if (isNaN(ratePerKg) || isNaN(weightValue)) {
            totalPriceElement.textContent = '-';
            return;
        }
        
        // Step 1: Convert the entered weight to Kilograms
        const weightInKg = weightValue * unitsToKg[weightUnit];

        // Step 2: Calculate the total price
        const totalPrice = ratePerKg * weightInKg;

        // Display the result, formatted to 2 decimal places
        totalPriceElement.textContent = `₹ ${totalPrice.toFixed(2)}`;
    };

    // Add event listeners to all inputs
    [rateInput, weightValueInput, weightUnitSelect].forEach(element => {
        element.addEventListener('input', calculatePrice);
    });

    // Initial calculation for any autofilled values
    calculatePrice();
});