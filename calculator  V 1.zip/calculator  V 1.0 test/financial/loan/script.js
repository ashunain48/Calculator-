document.addEventListener('DOMContentLoaded', () => {
    const amountInput = document.getElementById('loan-amount');
    const rateInput = document.getElementById('interest-rate');
    const termInput = document.getElementById('loan-term');
    const emiDisplay = document.getElementById('monthly-payment');
    const interestDisplay = document.getElementById('total-interest');

    function calculateLoan() {
        const P = parseFloat(amountInput.value); // Principal
        const annualRate = parseFloat(rateInput.value);
        const termYears = parseFloat(termInput.value);

        if (isNaN(P) || isNaN(annualRate) || isNaN(termYears) || P <= 0 || annualRate <= 0 || termYears <= 0) {
            emiDisplay.textContent = '-';
            interestDisplay.textContent = '-';
            return;
        }

        const r = (annualRate / 100) / 12; // Monthly interest rate
        const n = termYears * 12; // Number of months

        const emi = P * r * (Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1));
        const totalPayment = emi * n;
        const totalInterest = totalPayment - P;

        emiDisplay.textContent = emi.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        interestDisplay.textContent = totalInterest.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    
    [amountInput, rateInput, termInput].forEach(input => {
        input.addEventListener('input', calculateLoan);
    });
});