document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const modeRadios = document.querySelectorAll('input[name="mode"]');
    const numberInput = document.getElementById('number-input');
    const termSelect = document.getElementById('term-select');
    const resultWordsLabel = document.getElementById('result-words-label');
    const resultWords = document.getElementById('result-words');
    const resultDigits = document.getElementById('result-digits');

    let currentMode = 'int-to-ind';

    // EXPANDED terms with BigInt for massive numbers
    const terms = {
        international: [
            { name: 'Thousand', value: 10n ** 3n }, { name: 'Million', value: 10n ** 6n },
            { name: 'Billion', value: 10n ** 9n }, { name: 'Trillion', value: 10n ** 12n },
            { name: 'Quadrillion', value: 10n ** 15n }, { name: 'Quintillion', value: 10n ** 18n }
        ],
        indian: [
            { name: 'Thousand', value: 10n ** 3n }, { name: 'Lakh', value: 10n ** 5n },
            { name: 'Crore', value: 10n ** 7n }, { name: 'Arab', value: 10n ** 9n },
            { name: 'Kharab', value: 10n ** 11n }, { name: 'Neel', value: 10n ** 13n },
            { name: 'Padma', value: 10n ** 15n }, { name: 'Shankh', value: 10n ** 17n }
        ]
    };
    
    // --- Heavily Expanded Number to Words Logic ---
    function numberToWords(num, system = 'international') {
        if (num === 0n) return 'Zero';
        
        let numStr = num.toString();
        
        const units = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
        const teens = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
        const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
        
        function convertHundreds(n) {
            let word = '';
            if (n > 99) {
                word += units[Math.floor(n / 100)] + ' Hundred ';
                n %= 100;
            }
            if (n > 19) {
                word += tens[Math.floor(n / 10)] + ' ' + units[n % 10];
            } else if (n > 9) {
                word += teens[n - 10];
            } else {
                word += units[n];
            }
            return word.trim();
        }

        if (system === 'indian') {
            if (numStr.length > 19) return "Number too large (beyond Shankh)";
            const places = [
                { val: 10n ** 17n, name: 'Shankh' }, { val: 10n ** 15n, name: 'Padma' },
                { val: 10n ** 13n, name: 'Neel' }, { val: 10n ** 11n, name: 'Kharab' },
                { val: 10n ** 9n, name: 'Arab' }, { val: 10n ** 7n, name: 'Crore' },
                { val: 10n ** 5n, name: 'Lakh' }, { val: 10n ** 3n, name: 'Thousand' }
            ];
            let words = '';
            let tempNum = num;
            for (const place of places) {
                if (tempNum >= place.val) {
                    const count = tempNum / place.val;
                    words += numberToWords(count, 'indian') + ' ' + place.name + ' ';
                    tempNum %= place.val;
                }
            }
            if (tempNum > 0) {
                words += convertHundreds(Number(tempNum));
            }
            return words.trim();
        } else { // international
             if (numStr.length > 21) return "Number too large (beyond Quintillion)";
             const places = [
                { val: 10n ** 18n, name: 'Quintillion' }, { val: 10n ** 15n, name: 'Quadrillion' },
                { val: 10n ** 12n, name: 'Trillion' }, { val: 10n ** 9n, name: 'Billion' },
                { val: 10n ** 6n, name: 'Million' }, { val: 10n ** 3n, name: 'Thousand' }
             ];
             let words = '';
             let tempNum = num;
             for (const place of places) {
                 if (tempNum >= place.val) {
                     const count = tempNum / place.val;
                     words += numberToWords(count, 'international') + ' ' + place.name + ' ';
                     tempNum %= place.val;
                 }
             }
             if (tempNum > 0) {
                 words += convertHundreds(Number(tempNum));
             }
             return words.trim();
        }
    }

    // --- UI and Calculation Logic ---
    function updateUI() {
        const selectedTerms = (currentMode === 'int-to-ind') ? terms.international : terms.indian;
        
        termSelect.innerHTML = '';
        selectedTerms.forEach(term => {
            const option = document.createElement('option');
            option.value = term.value.toString(); // Store BigInt as string in value
            option.textContent = term.name;
            termSelect.appendChild(option);
        });

        if (currentMode === 'int-to-ind') {
            resultWordsLabel.textContent = 'In Indian System (Words)';
            termSelect.value = (10n ** 18n).toString(); // Default to Quintillion
        } else {
            resultWordsLabel.textContent = 'In International System (Words)';
            termSelect.value = (10n ** 17n).toString(); // Default to Shankh
        }
        calculate();
    }

    function calculate() {
        // Use BigInt for all calculations
        const num = BigInt(numberInput.value || 0);
        const multiplier = BigInt(termSelect.value || 0);

        if (num === 0n || multiplier === 0n) {
            resultWords.textContent = '-';
            resultDigits.textContent = '-';
            return;
        }

        const totalValue = num * multiplier;
        
        const targetSystem = (currentMode === 'int-to-ind') ? 'indian' : 'international';
        resultWords.textContent = numberToWords(totalValue, targetSystem);
        
        const locale = (targetSystem === 'indian') ? 'en-IN' : 'en-US';
        resultDigits.textContent = totalValue.toLocaleString(locale);
    }

    // --- Event Listeners ---
    modeRadios.forEach(radio => {
        radio.addEventListener('change', (e) => {
            currentMode = e.target.value;
            updateUI();
        });
    });

    [numberInput, termSelect].forEach(el => {
        el.addEventListener('input', calculate);
    });

    // --- Initial Load ---
    updateUI();
});