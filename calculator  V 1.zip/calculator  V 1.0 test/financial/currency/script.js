document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const amountInput = document.getElementById('amount');
    const fromCurrencySelect = document.getElementById('from-currency');
    const toCurrencySelect = document.getElementById('to-currency');
    const swapBtn = document.getElementById('swap-btn');
    const resultTitle = document.getElementById('result-title');
    const resultValue = document.getElementById('result-value');
    
    // UI State Elements
    const loadingMessage = document.getElementById('loading-message');
    const errorMessage = document.getElementById('error-message');
    const converterMain = document.getElementById('converter-main');
    const retryBtn = document.getElementById('retry-btn');

    // API URLs
    const RATES_API_URL = 'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json';
    const NAMES_API_URL = 'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies.json';

    let rates = {}; // Object to store the fetched conversion rates
    let currencyNames = {}; // Object to store currency codes and full names

    // --- Core Functions ---

    // Fetch both rates and names from the APIs and set up the page
    async function fetchAndPopulate() {
        loadingMessage.style.display = 'block';
        errorMessage.style.display = 'none';
        converterMain.style.display = 'none';

        try {
            // Fetch both APIs in parallel for speed
            const [ratesResponse, namesResponse] = await Promise.all([
                fetch(RATES_API_URL),
                fetch(NAMES_API_URL)
            ]);

            if (!ratesResponse.ok || !namesResponse.ok) throw new Error('Network response failed');
            
            const ratesData = await ratesResponse.json();
            const namesData = await namesResponse.json();
            
            rates = ratesData.usd;
            currencyNames = namesData;
            
            populateDropdowns();
            convertCurrency();
            
            converterMain.style.display = 'block';

        } catch (error) {
            console.error('Fetch error:', error);
            errorMessage.style.display = 'block';
        } finally {
            loadingMessage.style.display = 'none';
        }
    }

    // Populate the dropdowns with full currency names and codes
    function populateDropdowns() {
        const currencyCodes = Object.keys(rates);
        fromCurrencySelect.innerHTML = '';
        toCurrencySelect.innerHTML = '';

        currencyCodes.forEach(code => {
            const currencyName = currencyNames[code] || code.toUpperCase();
            // Format for display: "United States Dollar (USD)"
            const optionText = `${currencyName} (${code.toUpperCase()})`;
            
            fromCurrencySelect.add(new Option(optionText, code));
            toCurrencySelect.add(new Option(optionText, code));
        });

        // Set default values to common currencies
        fromCurrencySelect.value = 'usd'; // United States Dollar
        toCurrencySelect.value = 'inr'; // Indian Rupee
    }

    // Perform the currency conversion
    function convertCurrency() {
        const amount = parseFloat(amountInput.value);
        const fromCurrency = fromCurrencySelect.value;
        const toCurrency = toCurrencySelect.value;

        if (isNaN(amount) || !rates[fromCurrency] || !rates[toCurrency]) {
            resultValue.textContent = '-';
            resultTitle.textContent = 'Converted Amount';
            return;
        }

        const amountInUSD = amount / rates[fromCurrency];
        const convertedAmount = amountInUSD * rates[toCurrency];

        const formattedAmount = amount.toLocaleString();
        const formattedResult = convertedAmount.toLocaleString(undefined, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
        
        const fromCurrencyDisplay = fromCurrency.toUpperCase();
        const toCurrencyDisplay = toCurrency.toUpperCase();

        resultTitle.textContent = `${formattedAmount} ${fromCurrencyDisplay} equals`;
        resultValue.textContent = `${formattedResult} ${toCurrencyDisplay}`;
    }

    // Swap the 'from' and 'to' currencies and recalculate
    function swapCurrencies() {
        const temp = fromCurrencySelect.value;
        fromCurrencySelect.value = toCurrencySelect.value;
        toCurrencySelect.value = temp;
        convertCurrency();
    }

    // --- Event Listeners ---
    amountInput.addEventListener('input', convertCurrency);
    fromCurrencySelect.addEventListener('change', convertCurrency);
    toCurrencySelect.addEventListener('change', convertCurrency);
    swapBtn.addEventListener('click', swapCurrencies);
    retryBtn.addEventListener('click', fetchAndPopulate);

    // --- Initial Load ---
    fetchAndPopulate();
});