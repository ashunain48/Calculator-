document.addEventListener('DOMContentLoaded', () => {
    const initialInput = document.getElementById('initial-investment');
    const monthlyInput = document.getElementById('monthly-contribution');
    const rateInput = document.getElementById('interest-rate');
    const periodInput = document.getElementById('period-years');
    const futureValueDisplay = document.getElementById('future-value');
    const interestEarnedDisplay = document.getElementById('interest-earned');
    
    function calculateInvestment() {
        const P = parseFloat(initialInput.value) || 0;
        const PMT = parseFloat(monthlyInput.value) || 0;
        const annualRate = parseFloat(rateInput.value) || 0;
        const t = parseFloat(periodInput.value) || 0;

        if (t <= 0 || annualRate < 0) {
            futureValueDisplay.textContent = '-';
            interestEarnedDisplay.textContent = '-';
            return;
        }

        const r = (annualRate / 100) / 12; // monthly interest rate
        const n = t * 12; // number of months

        // Future value of initial investment
        const fvPrincipal = P * Math.pow(1 + r, n);
        // Future value of monthly contributions (annuity)
        const fvContributions = PMT * ((Math.pow(1 + r, n) - 1) / r);

        const totalFv = fvPrincipal + fvContributions;
        const totalContributions = P + (PMT * n);
        const totalInterest = totalFv - totalContributions;

        futureValueDisplay.textContent = totalFv.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        interestEarnedDisplay.textContent = totalInterest.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    [initialInput, monthlyInput, rateInput, periodInput].forEach(input => {
        input.addEventListener('input', calculateInvestment);
    });
});