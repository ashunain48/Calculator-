document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const unitRadios = document.querySelectorAll('input[name="units"]');
    const distanceInput = document.getElementById('distance');
    const fuelInput = document.getElementById('fuel');
    const costInput = document.getElementById('cost');
    
    // Label and Result Elements
    const unitDistanceSpans = document.querySelectorAll('.unit-distance');
    const unitFuelSpans = document.querySelectorAll('.unit-fuel');
    const efficiencyLabel = document.getElementById('efficiency-label');
    const costLabel = document.getElementById('cost-label');
    const efficiencyResult = document.getElementById('efficiency-result');
    const costResult = document.getElementById('cost-result');

    let currentUnit = 'metric';

    const updateLabels = () => {
        if (currentUnit === 'metric') {
            unitDistanceSpans.forEach(span => span.textContent = 'km');
            unitFuelSpans.forEach(span => span.textContent = 'L');
            efficiencyLabel.textContent = 'L / 100km';
            costLabel.textContent = 'Cost / km';
        } else { // imperial
            unitDistanceSpans.forEach(span => span.textContent = 'miles');
            unitFuelSpans.forEach(span => span.textContent = 'gal');
            efficiencyLabel.textContent = 'MPG';
            costLabel.textContent = 'Cost / mile';
        }
        calculateEfficiency(); // Recalculate when units change
    };

    const calculateEfficiency = () => {
        const distance = parseFloat(distanceInput.value);
        const fuel = parseFloat(fuelInput.value);
        const cost = parseFloat(costInput.value);

        // Calculate and display efficiency
        if (!isNaN(distance) && distance > 0 && !isNaN(fuel) && fuel > 0) {
            let efficiency;
            if (currentUnit === 'metric') {
                // Liters per 100 kilometers
                efficiency = (fuel / distance) * 100;
            } else { // imperial
                // Miles per gallon
                efficiency = distance / fuel;
            }
            efficiencyResult.textContent = efficiency.toFixed(2);
        } else {
            efficiencyResult.textContent = '-';
        }

        // Calculate and display cost per distance
        if (!isNaN(distance) && distance > 0 && !isNaN(cost) && cost > 0) {
            const costPerUnitDistance = cost / distance;
            costResult.textContent = costPerUnitDistance.toFixed(2);
        } else {
            costResult.textContent = '-';
        }
    };

    // Add event listeners
    unitRadios.forEach(radio => {
        radio.addEventListener('change', (e) => {
            currentUnit = e.target.value;
            updateLabels();
        });
    });

    [distanceInput, fuelInput, costInput].forEach(input => {
        input.addEventListener('input', calculateEfficiency);
    });

    // Initial setup
    updateLabels();
});