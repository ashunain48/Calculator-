document.addEventListener('DOMContentLoaded', () => {
    // Get all necessary DOM elements
    const startDateInput = document.getElementById('start-date');
    const operationRadios = document.querySelectorAll('input[name="operation"]');
    const yearsInput = document.getElementById('years-input');
    const monthsInput = document.getElementById('months-input');
    const weeksInput = document.getElementById('weeks-input');
    const daysInput = document.getElementById('days-input');
    const resultDateElement = document.getElementById('result-date');

    // Set the default start date to today
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0'); // Months are 0-based
    const dd = String(today.getDate()).padStart(2, '0');
    startDateInput.value = `${yyyy}-${mm}-${dd}`;

    // Function to perform the date calculation
    const calculateDate = () => {
        const startDateValue = startDateInput.value;
        if (!startDateValue) {
            resultDateElement.textContent = '-';
            return;
        }

        // Get the selected operation (add or subtract)
        const operation = document.querySelector('input[name="operation"]:checked').value;
        const multiplier = (operation === 'add') ? 1 : -1;

        // Get the values to add/subtract, defaulting to 0 if empty
        const years = parseInt(yearsInput.value) || 0;
        const months = parseInt(monthsInput.value) || 0;
        const weeks = parseInt(weeksInput.value) || 0;
        const days = parseInt(daysInput.value) || 0;

        // Create a date object from the start date input value
        // Splitting and creating date this way avoids timezone issues
        const [year, month, day] = startDateValue.split('-').map(Number);
        const resultDate = new Date(year, month - 1, day);

        // Perform the date modifications. Order matters for accuracy (Y, M, D).
        if (years !== 0) {
            resultDate.setFullYear(resultDate.getFullYear() + (years * multiplier));
        }
        if (months !== 0) {
            resultDate.setMonth(resultDate.getMonth() + (months * multiplier));
        }
        if (weeks !== 0 || days !== 0) {
            resultDate.setDate(resultDate.getDate() + ((days + weeks * 7) * multiplier));
        }
        
        // Format the final date for display
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        resultDateElement.textContent = resultDate.toLocaleDateString('en-US', options);
    };

    // Add event listeners to all inputs to trigger recalculation on change
    const inputs = [startDateInput, yearsInput, monthsInput, weeksInput, daysInput];
    inputs.forEach(input => input.addEventListener('input', calculateDate));
    operationRadios.forEach(radio => radio.addEventListener('change', calculateDate));

    // Perform an initial calculation on page load
    calculateDate();
});