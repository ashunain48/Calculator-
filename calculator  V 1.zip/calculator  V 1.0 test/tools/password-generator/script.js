document.addEventListener('DOMContentLoaded', () => {
    const passwordOutput = document.getElementById('password-output');
    const copyBtn = document.getElementById('copy-btn');
    const lengthSlider = document.getElementById('length-slider');
    const lengthDisplay = document.getElementById('length-display');
    const includeUppercase = document.getElementById('include-uppercase');
    const includeLowercase = document.getElementById('include-lowercase');
    const includeNumbers = document.getElementById('include-numbers');
    const includeSymbols = document.getElementById('include-symbols');
    const generateBtn = document.getElementById('generate-btn');

    const charSets = {
        uppercase: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
        lowercase: 'abcdefghijklmnopqrstuvwxyz',
        numbers: '0123456789',
        symbols: '!@#$%^&*()_+-=[]{}|;:,.<>?'
    };

    function generatePassword() {
        const length = parseInt(lengthSlider.value);
        let masterCharSet = '';
        let generatedPassword = '';

        if (includeUppercase.checked) masterCharSet += charSets.uppercase;
        if (includeLowercase.checked) masterCharSet += charSets.lowercase;
        if (includeNumbers.checked) masterCharSet += charSets.numbers;
        if (includeSymbols.checked) masterCharSet += charSets.symbols;

        if (masterCharSet === '') {
            passwordOutput.textContent = 'Select at least one option';
            return;
        }

        for (let i = 0; i < length; i++) {
            const randomIndex = Math.floor(Math.random() * masterCharSet.length);
            generatedPassword += masterCharSet[randomIndex];
        }

        passwordOutput.textContent = generatedPassword;
    }
    
    lengthSlider.addEventListener('input', () => {
        lengthDisplay.textContent = lengthSlider.value;
    });

    generateBtn.addEventListener('click', generatePassword);

    copyBtn.addEventListener('click', () => {
        const password = passwordOutput.textContent;
        if (password && password !== 'Click Generate...' && password !== 'Select at least one option') {
            navigator.clipboard.writeText(password).then(() => {
                copyBtn.innerHTML = '<i class="fas fa-check"></i>';
                setTimeout(() => {
                    copyBtn.innerHTML = '<i class="far fa-copy"></i>';
                }, 1500);
            });
        }
    });

    // Initial password generation on load
    generatePassword();
});