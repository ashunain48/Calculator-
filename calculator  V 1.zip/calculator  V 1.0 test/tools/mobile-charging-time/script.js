document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const capacityInput = document.getElementById('battery-capacity');
    const levelInput = document.getElementById('current-level');
    const voltageInput = document.getElementById('charger-voltage');
    const currentInput = document.getElementById('charger-current');
    const resultElement = document.getElementById('charging-time-result');

    const calculateTime = () => {
        const capacity = parseFloat(capacityInput.value);
        const currentLevel = parseFloat(levelInput.value);
        const chargerVoltage = parseFloat(voltageInput.value);
        const chargerCurrent = parseFloat(currentInput.value);

        // Validate inputs
        if (isNaN(capacity) || isNaN(currentLevel) || isNaN(chargerVoltage) || isNaN(chargerCurrent) ||
            capacity <= 0 || chargerVoltage <= 0 || chargerCurrent <= 0) {
            resultElement.textContent = '-';
            return;
        }
        
        // Constants for calculation
        const BATTERY_VOLTAGE = 3.7; // Average voltage for a Li-ion cell
        const EFFICIENCY_FACTOR = 1.25; // Accounts for ~80% charging efficiency (energy loss as heat)

        // Calculate charger power in Watts
        const chargerPowerW = chargerVoltage * chargerCurrent;

        // Calculate the total energy capacity of the battery in Watt-hours (Wh)
        const batteryEnergyWh = (capacity * BATTERY_VOLTAGE) / 1000;

        // Calculate the energy needed to reach 100%
        const energyNeededWh = batteryEnergyWh * ((100 - currentLevel) / 100);

        // Calculate charging time in decimal hours, including the inefficiency factor
        const timeHoursDecimal = (energyNeededWh / chargerPowerW) * EFFICIENCY_FACTOR;

        // Convert decimal hours to hours and minutes
        const hours = Math.floor(timeHoursDecimal);
        const minutes = Math.round((timeHoursDecimal - hours) * 60);

        // Format the output string
        let resultString = '';
        if (hours > 0) {
            resultString += `${hours} hr `;
        }
        resultString += `${minutes} min`;
        
        resultElement.textContent = resultString.trim();
    };

    // Add event listeners to all input fields
    [capacityInput, levelInput, voltageInput, currentInput].forEach(input => {
        input.addEventListener('input', calculateTime);
    });

    // Initial calculation
    calculateTime();
});