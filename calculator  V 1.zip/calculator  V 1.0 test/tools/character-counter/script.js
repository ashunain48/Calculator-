document.addEventListener('DOMContentLoaded', () => {
    const textInput = document.getElementById('text-input');
    const charCount = document.getElementById('char-count');
    const wordCount = document.getElementById('word-count');
    const lineCount = document.getElementById('line-count');
    const sentenceCount = document.getElementById('sentence-count');

    function updateCounts() {
        const text = textInput.value;

        // Character count
        charCount.textContent = text.length;

        // Word count
        const words = text.trim().split(/\s+/).filter(word => word !== '');
        wordCount.textContent = words.length === 1 && words[0] === '' ? 0 : words.length;

        // Line count
        const lines = text.split('\n');
        lineCount.textContent = lines.length;
        
        // Sentence count (basic)
        const sentences = text.match(/[^\.!\?]+[\.!\?]+/g);
        sentenceCount.textContent = sentences ? sentences.length : 0;
    }

    textInput.addEventListener('input', updateCounts);
});