document.addEventListener('DOMContentLoaded', () => {
    const band1Select = document.getElementById('band-1-select');
    const band2Select = document.getElementById('band-2-select');
    const band3Select = document.getElementById('band-3-select');
    const band4Select = document.getElementById('band-4-select');
    const bandVisuals = {
        1: document.getElementById('band-1-visual'),
        2: document.getElementById('band-2-visual'),
        3: document.getElementById('band-3-visual'),
        4: document.getElementById('band-4-visual'),
    };
    const resultElement = document.getElementById('resistance-result');

    const colorData = {
        black:  { value: 0, multiplier: 1,      tolerance: null,   hex: '#000000',textColor: 'white' },
        brown:  { value: 1, multiplier: 10,     tolerance: '±1%',  hex: '#a52a2a',textColor: 'white' },
        red:    { value: 2, multiplier: 100,    tolerance: '±2%',  hex: '#ff0000',textColor: 'white' },
        orange: { value: 3, multiplier: 1000,   tolerance: null,   hex: '#ffa500',textColor: 'black' },
        yellow: { value: 4, multiplier: 10000,  tolerance: null,   hex: '#ffff00',textColor: 'black' },
        green:  { value: 5, multiplier: 100000, tolerance: '±0.5%',hex: '#008000',textColor: 'white' },
        blue:   { value: 6, multiplier: 1000000,tolerance: '±0.25%',hex: '#0000ff',textColor: 'white' },
        violet: { value: 7, multiplier: 10000000,tolerance:'±0.1%',hex: '#ee82ee',textColor: 'black' },
        grey:   { value: 8, multiplier: null,   tolerance: '±0.05%',hex: '#808080',textColor: 'white' },
        white:  { value: 9, multiplier: null,   tolerance: null,   hex: '#ffffff',textColor: 'black' },
        gold:   { value: null,multiplier: 0.1,    tolerance: '±5%',  hex: '#ffd700',textColor: 'black' },
        silver: { value: null,multiplier: 0.01,   tolerance: '±10%', hex: '#c0c0c0',textColor: 'black' },
    };

    function populateSelects() {
        // Band 1 (No Black) & 2
        Object.entries(colorData).forEach(([name, data]) => {
            if (data.value !== null) {
                if (name !== 'black') createOption(band1Select, name, data);
                createOption(band2Select, name, data);
            }
        });

        // Multiplier
        Object.entries(colorData).forEach(([name, data]) => {
            if (data.multiplier !== null) createOption(band3Select, name, data);
        });

        // Tolerance
        Object.entries(colorData).forEach(([name, data]) => {
            if (data.tolerance !== null) createOption(band4Select, name, data);
        });
        
        // Set default values
        band1Select.value = 'orange';
        band2Select.value = 'orange';
        band3Select.value = 'brown';
        band4Select.value = 'gold';
    }

    function createOption(selectElement, name, data) {
        const option = document.createElement('option');
        option.value = name;
        option.textContent = name.charAt(0).toUpperCase() + name.slice(1);
        option.style.backgroundColor = data.hex;
        option.style.color = data.textColor === 'white' ? '#FFFFFF' : '#000000';
        selectElement.appendChild(option);
    }
    
    function formatResistance(value) {
        if (value >= 1000000) {
            return (value / 1000000).toFixed(2).replace(/\.00$/, '').replace(/\.?0+$/, '') + ' MΩ';
        }
        if (value >= 1000) {
            return (value / 1000).toFixed(2).replace(/\.00$/, '').replace(/\.?0+$/, '') + ' kΩ';
        }
        return value + ' Ω';
    }

    function updateCalculator() {
        const selects = [band1Select, band2Select, band3Select, band4Select];
        
        selects.forEach((select, index) => {
            const colorName = select.value;
            const colorInfo = colorData[colorName];
            
            // Update visual resistor band on the image
            bandVisuals[index + 1].style.backgroundColor = colorInfo.hex;
            
            // --- THIS IS THE FIX ---
            // Update the dropdown box's color and text color itself
            select.style.backgroundColor = colorInfo.hex;
            select.style.color = colorInfo.textColor;
        });

        const val1 = colorData[band1Select.value].value;
        const val2 = colorData[band2Select.value].value;
        const multiplier = colorData[band3Select.value].multiplier;
        const tolerance = colorData[band4Select.value].tolerance;
        
        const baseValue = parseInt(`${val1}${val2}`);
        const totalResistance = baseValue * multiplier;
        
        resultElement.textContent = `${formatResistance(totalResistance)} ${tolerance}`;
    }

    // Add event listeners
    [band1Select, band2Select, band3Select, band4Select].forEach(select => {
        select.addEventListener('change', updateCalculator);
    });

    // Initial setup
    populateSelects();
    updateCalculator();
});