document.addEventListener('DOMContentLoaded', () => {
    // Get all necessary DOM elements
    const startTimeInput = document.getElementById('start-time');
    const operationRadios = document.querySelectorAll('input[name="operation"]');
    const hoursInput = document.getElementById('hours-input');
    const minutesInput = document.getElementById('minutes-input');
    const secondsInput = document.getElementById('seconds-input');
    const resultTimeElement = document.getElementById('result-time');

    // Set the default start time to the current time
    const now = new Date();
    const currentHours = String(now.getHours()).padStart(2, '0');
    const currentMinutes = String(now.getMinutes()).padStart(2, '0');
    startTimeInput.value = `${currentHours}:${currentMinutes}`;

    // Function to perform the time calculation
    const calculateTime = () => {
        const startTimeValue = startTimeInput.value;
        if (!startTimeValue) {
            resultTimeElement.textContent = '-';
            return;
        }

        // Get the selected operation (add or subtract)
        const operation = document.querySelector('input[name="operation"]:checked').value;
        const multiplier = (operation === 'add') ? 1 : -1;

        // Get the values to add/subtract, defaulting to 0 if empty
        const hours = parseInt(hoursInput.value) || 0;
        const minutes = parseInt(minutesInput.value) || 0;
        const seconds = parseInt(secondsInput.value) || 0;

        // Create a Date object to handle time calculations and rollovers
        const baseDate = new Date();
        const [startHours, startMinutes] = startTimeValue.split(':').map(Number);
        
        baseDate.setHours(startHours);
        baseDate.setMinutes(startMinutes);
        baseDate.setSeconds(0); // Start with 0 seconds as input type="time" doesn't provide it

        // Perform the time modifications
        baseDate.setHours(baseDate.getHours() + (hours * multiplier));
        baseDate.setMinutes(baseDate.getMinutes() + (minutes * multiplier));
        baseDate.setSeconds(baseDate.getSeconds() + (seconds * multiplier));
        
        // Format the final time for display (12-hour format with AM/PM)
        const resultHours24 = baseDate.getHours();
        const resultMinutes = String(baseDate.getMinutes()).padStart(2, '0');
        const resultSeconds = String(baseDate.getSeconds()).padStart(2, '0');
        
        const period = resultHours24 >= 12 ? 'PM' : 'AM';
        const resultHours12 = resultHours24 % 12 || 12; // Converts 0 to 12 for midnight

        resultTimeElement.textContent = `${resultHours12}:${resultMinutes}:${resultSeconds} ${period}`;
    };

    // Add event listeners to all inputs to trigger recalculation on change
    const inputs = [startTimeInput, hoursInput, minutesInput, secondsInput];
    inputs.forEach(input => input.addEventListener('input', calculateTime));
    operationRadios.forEach(radio => radio.addEventListener('change', calculateTime));

    // Perform an initial calculation on page load
    calculateTime();
});