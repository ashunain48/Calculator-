document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const readingInput = document.getElementById('lactometer-reading');
    const tempInput = document.getElementById('milk-temperature');
    const resultValueElement = document.getElementById('result-value');
    const resultInterpretationElement = document.getElementById('result-interpretation');

    // Constants for the calculation
    // Standard temperature for lactometer calibration is 20°C.
    const STANDARD_TEMP_C = 20;
    // The correction factor is typically +0.2 for every 1°C above the standard,
    // and -0.2 for every 1°C below.
    const CORRECTION_FACTOR = 0.2;

    const calculateCLR = () => {
        const observedReading = parseFloat(readingInput.value);
        const milkTemp = parseFloat(tempInput.value);

        // Check if both inputs are valid numbers
        if (isNaN(observedReading) || isNaN(milkTemp)) {
            resultValueElement.textContent = '-';
            resultInterpretationElement.textContent = 'Please enter valid numbers.';
            return;
        }

        // Calculate the temperature difference
        const tempDifference = milkTemp - STANDARD_TEMP_C;

        // Calculate the Corrected Lactometer Reading (CLR)
        const clr = observedReading + (tempDifference * CORRECTION_FACTOR);

        // Display the result, formatted to two decimal places
        resultValueElement.textContent = clr.toFixed(2);

        // Provide an interpretation of the result
        let interpretation = '';
        if (clr < 26) {
            interpretation = 'Low reading. This may indicate adulteration with water.';
        } else if (clr >= 26 && clr <= 32) {
            interpretation = 'Normal reading. This indicates good quality, unadulterated milk.';
        } else {
            interpretation = 'High reading. This may indicate the removal of fat or the addition of solids like skim milk powder.';
        }
        resultInterpretationElement.textContent = interpretation;
    };

    // Add event listeners to both input fields
    const inputs = [readingInput, tempInput];
    inputs.forEach(input => input.addEventListener('input', calculateCLR));

    // Perform an initial calculation in case of autofill
    calculateCLR();
});