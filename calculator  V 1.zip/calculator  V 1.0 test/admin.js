document.addEventListener('DOMContentLoaded', () => {
    // Banner Elements
    const bannerInput = document.getElementById('admin-banner-message');
    const saveBannerBtn = document.getElementById('save-banner-btn');

    // Link Elements
    const linkNameInput = document.getElementById('admin-link-name');
    const linkUrlInput = document.getElementById('admin-link-url');
    const addLinkBtn = document.getElementById('add-link-btn');
    const linkList = document.getElementById('link-list');

    const feedbackMessage = document.getElementById('feedback-message');

    // --- Load existing data from localStorage on page load ---
    function loadData() {
        // Load banner
        const savedBanner = localStorage.getItem('bannerMessage');
        if (savedBanner) {
            bannerInput.value = savedBanner;
        }
        // Load links
        renderLinks();
    }

    // --- Banner Logic ---
    saveBannerBtn.addEventListener('click', () => {
        localStorage.setItem('bannerMessage', bannerInput.value);
        showFeedback();
    });

    // --- Links Logic ---
    function getLinks() {
        return JSON.parse(localStorage.getItem('usefulLinks')) || [];
    }

    function saveLinks(links) {
        localStorage.setItem('usefulLinks', JSON.stringify(links));
    }

    function renderLinks() {
        const links = getLinks();
        linkList.innerHTML = ''; // Clear current list
        links.forEach((link, index) => {
            const li = document.createElement('li');
            li.innerHTML = `
                <span>${link.name} (${link.url})</span>
                <button class="remove-btn" data-index="${index}">Remove</button>
            `;
            linkList.appendChild(li);
        });
    }

    addLinkBtn.addEventListener('click', () => {
        const name = linkNameInput.value.trim();
        const url = linkUrlInput.value.trim();

        if (name && url) {
            const links = getLinks();
            links.push({ name, url });
            saveLinks(links);
            renderLinks();
            linkNameInput.value = '';
            linkUrlInput.value = '';
            showFeedback();
        } else {
            alert('Please fill in both Link Name and URL.');
        }
    });

    linkList.addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-btn')) {
            const index = parseInt(e.target.dataset.index, 10);
            const links = getLinks();
            links.splice(index, 1); // Remove the item at the specified index
            saveLinks(links);
            renderLinks();
            showFeedback();
        }
    });

    function showFeedback() {
        feedbackMessage.style.display = 'block';
        setTimeout(() => {
            feedbackMessage.style.display = 'none';
        }, 1500);
    }

    // Initial load
    loadData();
});