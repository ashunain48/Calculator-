document.addEventListener('DOMContentLoaded', () => {
    // --- Main Screen Switching Logic ---
    const screens = document.querySelectorAll('.screen');
    const navIcons = document.querySelectorAll('.nav-icons i');

    function showScreen(screenId) {
        screens.forEach(screen => {
            screen.classList.toggle('active', screen.id === screenId);
        });
        navIcons.forEach(icon => {
            const targetScreen = icon.id.replace('show-', '') + '-screen';
            icon.classList.toggle('active-nav', targetScreen === screenId);
        });
    }

    // Attach event listeners to all navigation icons
    document.getElementById('show-calculator').addEventListener('click', () => showScreen('calculator-screen'));
    document.getElementById('show-converters').addEventListener('click', () => showScreen('converters-screen'));
    document.getElementById('show-powers').addEventListener('click', () => showScreen('powers-screen'));
    document.getElementById('show-financial').addEventListener('click', () => showScreen('financial-screen'));
    document.getElementById('show-tools').addEventListener('click', () => showScreen('tools-screen'));
    
    document.getElementById('show-settings').addEventListener('click', () => {
        showScreen('settings-screen');
        loadAdminSettings();
    });

    // --- Calculator Screen Logic (remains unchanged) ---
    // ... (all the calculator, history, and scientific button logic is here and correct) ...
    const expressionInput = document.getElementById('expression');
    const resultInput = document.getElementById('result');
    const buttonsContainer = document.querySelector('.buttons-container');
    const calculatorScreen = document.getElementById('calculator-screen');
    const historyBtn = document.getElementById('history-btn');
    const historyPanel = document.getElementById('history-panel');
    const closeHistoryBtn = document.getElementById('close-history-btn');
    const historyList = document.getElementById('history-list');
    const toggleDegBtn = document.getElementById('toggle-deg');
    const toggle2ndBtn = document.getElementById('toggle-2nd');
    let history = [];
    let isDeg = true;
    let is2ndActive = false;
    buttonsContainer.addEventListener('click', e => {
        const button = e.target.closest('button');
        if (!button) return;
        const { value } = button.dataset;
        handleInput(value);
    });
    function handleInput(value) {
        if (!value) return;
        const currentExpression = expressionInput.value;
        switch (value) {
            case '=': calculateResult(true); return;
            case 'C': expressionInput.value = '0'; resultInput.value = ''; return;
            case 'DEL': expressionInput.value = currentExpression.slice(0, -1) || '0'; break;
            case 'toggle-sci': calculatorScreen.classList.toggle('scientific-mode-active'); return;
            case '2nd': toggle2ndFunctions(); return;
            case 'deg': isDeg = !isDeg; toggleDegBtn.textContent = isDeg ? 'deg' : 'rad'; return;
            default:
                if (currentExpression === '0' && !'×÷+-.'.includes(value)) {
                    expressionInput.value = value;
                } else {
                    expressionInput.value += value;
                }
                break;
        }
        calculateResult(false);
    }
    function calculateResult(isFinal) {
        let expr = expressionInput.value;
        if (!expr) return;
        try {
            let processedExpr = expr.replace(/×/g, '*').replace(/÷/g, '/').replace(/π/g, 'Math.PI').replace(/e/g, 'Math.E').replace(/\^/g, '**').replace(/lg\(/g, 'Math.log10(').replace(/ln\(/g, 'Math.log(').replace(/sqrt\(/g, 'Math.sqrt(').replace(/cbrt\(/g, 'Math.cbrt(').replace(/nrt/g, '** (1 /').replace(/10\^/g, '10**').replace(/e\^/g, 'Math.exp');
            const trigRegex = /(\bas[incotah]+\b)\(([^)]*)\)/g;
            processedExpr = processedExpr.replace(trigRegex, (match, func, val) => {
                let angle = eval(val);
                if (isDeg) {
                    if (func.startsWith('a')) { return `(Math.${func}(${angle}) * 180 / Math.PI)`; }
                    return `Math.${func}(${angle} * Math.PI / 180)`;
                }
                return `Math.${func}(${angle})`;
            });
            if (/[*\/+\-.]$/.test(processedExpr)) { if (!isFinal) resultInput.value = ''; return; }
            const result = eval(processedExpr);
            const finalResult = parseFloat(result.toPrecision(12));
            if (isFinal) {
                expressionInput.value = finalResult;
                resultInput.value = '';
                addToHistory(expr, finalResult);
            } else {
                resultInput.value = finalResult;
            }
        } catch (error) { if (!isFinal) { resultInput.value = ''; } }
    }
    function toggle2ndFunctions() {
        is2ndActive = !is2ndActive;
        toggle2ndBtn.classList.toggle('active', is2ndActive);
        const buttonsToToggle = document.querySelectorAll('[data-2nd]');
        buttonsToToggle.forEach(btn => {
            const originalValue = btn.dataset.value;
            const secondValue = btn.dataset['2nd'];
            btn.dataset.value = secondValue;
            btn.dataset['2nd'] = originalValue;
            const originalHTML = btn.innerHTML;
            const secondHTML = btn.dataset.secondHtml || secondValue;
            btn.innerHTML = secondHTML;
            btn.dataset.secondHtml = originalHTML;
        });
    }
    function addToHistory(expression, result) {
        history.unshift({ expression, result });
        if (history.length > 20) history.pop();
        updateHistoryPanel();
    }
    function updateHistoryPanel() {
        if (history.length === 0) {
            historyList.innerHTML = '<p class="no-history">No history yet.</p>';
        } else {
            historyList.innerHTML = history.map(item => `<div class="history-item"><p class="expr">${item.expression}</p><p class="res">= ${item.result}</p></div>`).join('');
        }
    }
    historyBtn.addEventListener('click', () => historyPanel.classList.add('show'));
    closeHistoryBtn.addEventListener('click', () => historyPanel.classList.remove('show'));
    
    // --- Settings Screen Logic ---
    function loadAdminSettings() {
        const bannerContainer = document.getElementById('banner-message-container');
        const linksContainer = document.getElementById('useful-links-container');
        const bannerMessage = localStorage.getItem('bannerMessage');
        if (bannerMessage && bannerMessage.trim() !== '') {
            bannerContainer.textContent = bannerMessage;
            bannerContainer.style.display = 'block';
        } else {
            bannerContainer.style.display = 'none';
        }
        const usefulLinks = JSON.parse(localStorage.getItem('usefulLinks')) || [];
        linksContainer.innerHTML = '';
        if (usefulLinks.length > 0) {
            let linksHTML = '<h3 class="useful-links-title">Useful Links</h3>';
            usefulLinks.forEach(link => {
                linksHTML += `<a href="${link.url}" target="_blank" class="useful-link-item">${link.name}</a>`;
            });
            linksContainer.innerHTML = linksHTML;
        }
    }
    if(document.getElementById('settings-screen').classList.contains('active')){
        loadAdminSettings();
    }

    // --- NEW: Secret Admin Panel Access ---
    const appVersionElement = document.getElementById('app-version');
    let clickCount = 0;
    let clickTimer = null;

    appVersionElement.addEventListener('click', () => {
        clickCount++;

        // Reset the counter if there's a pause of more than 1 second between clicks
        clearTimeout(clickTimer);
        clickTimer = setTimeout(() => {
            clickCount = 0;
        }, 1000);

        // If the user clicks 7 times in a row, open the admin panel
        if (clickCount >= 7) {
            window.location.href = 'admin.html';
            clickCount = 0;
            clearTimeout(clickTimer);
        }
    });

});