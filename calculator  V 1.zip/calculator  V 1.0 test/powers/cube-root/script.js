document.addEventListener('DOMContentLoaded', () => {
    const numberInput = document.getElementById('number-input');
    const resultValue = document.getElementById('result-value');

    function calculateCubeRoot() {
        const inputValue = numberInput.value;

        // If the input is empty, reset the result display
        if (inputValue.trim() === '') {
            resultValue.textContent = '-';
            return;
        }

        const number = parseFloat(inputValue);

        // Check if the parsed value is a valid number
        if (isNaN(number)) {
            resultValue.textContent = 'Invalid Input';
            return;
        }

        // Calculate the cube root using Math.cbrt(), which handles negatives
        const cubeRoot = Math.cbrt(number);

        // Display the result, formatted with commas for readability
        resultValue.textContent = cubeRoot.toLocaleString();
    }

    // Add an event listener to the input field to calculate on every change
    numberInput.addEventListener('input', calculateCubeRoot);

    // Initial calculation to set the correct state on page load
    calculateCubeRoot();
});