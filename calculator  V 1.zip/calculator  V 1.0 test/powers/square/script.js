document.addEventListener('DOMContentLoaded', () => {
    const numberInput = document.getElementById('number-input');
    const resultValue = document.getElementById('result-value');

    function calculateSquare() {
        const inputValue = numberInput.value;

        // If the input is empty, reset the result display
        if (inputValue.trim() === '') {
            resultValue.textContent = '-';
            return;
        }

        const number = parseFloat(inputValue);

        // Check if the parsed value is a valid number
        if (isNaN(number)) {
            resultValue.textContent = 'Invalid Input';
            return;
        }

        // Calculate the square
        const square = Math.pow(number, 2);

        // Display the result, formatted with commas for readability
        resultValue.textContent = square.toLocaleString();
    }

    // Add an event listener to the input field to calculate on every change
    numberInput.addEventListener('input', calculateSquare);

    // Initial calculation to set the correct state on page load
    calculateSquare();
});