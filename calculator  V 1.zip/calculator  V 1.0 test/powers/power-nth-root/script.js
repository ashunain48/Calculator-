document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const calcTypeRadios = document.querySelectorAll('input[name="calc-type"]');
    const baseInput = document.getElementById('base-number');
    const powerInput = document.getElementById('power-number');
    const baseLabel = document.getElementById('base-label');
    const powerLabel = document.getElementById('power-label');
    const resultElement = document.getElementById('result-value');

    let currentMode = 'power';

    const updateUI = () => {
        if (currentMode === 'power') {
            baseLabel.textContent = 'Base (x)';
            powerLabel.textContent = 'Power (y)';
        } else { // root
            baseLabel.textContent = 'Number (x)';
            powerLabel.textContent = 'Root (y)';
        }
        calculate(); // Recalculate when UI changes
    };

    const calculate = () => {
        const base = parseFloat(baseInput.value);
        const power = parseFloat(powerInput.value);

        if (isNaN(base) || isNaN(power)) {
            resultElement.textContent = '-';
            return;
        }
        
        let result;
        if (currentMode === 'power') {
            result = Math.pow(base, power);
        } else { // root
            if (base < 0 && power % 2 === 0) {
                resultElement.textContent = 'Invalid'; // Cannot take an even root of a negative number
                return;
            }
            // Math.pow(base, 1/power) is equivalent to nth root
            result = Math.pow(base, 1 / power);
        }

        // Format result to remove unnecessary decimals and use toLocaleString for large numbers
        resultElement.textContent = parseFloat(result.toPrecision(12)).toLocaleString();
    };

    // Add event listeners
    calcTypeRadios.forEach(radio => {
        radio.addEventListener('change', (e) => {
            currentMode = e.target.value;
            updateUI();
        });
    });

    [baseInput, powerInput].forEach(input => {
        input.addEventListener('input', calculate);
    });

    // Initial setup
    updateUI();
});