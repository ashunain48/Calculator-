document.addEventListener('DOMContentLoaded', () => {
    const startInput = document.getElementById('start-number');
    const endInput = document.getElementById('end-number');
    const resultsTbody = document.getElementById('results-tbody');
    const errorMessage = document.getElementById('error-message');

    const MAX_RANGE = 200; // Limit to prevent browser freezing

    const calculateRange = () => {
        let start = parseInt(startInput.value);
        let end = parseInt(endInput.value);
        
        errorMessage.style.display = 'none';
        resultsTbody.innerHTML = '';

        if (isNaN(start) || isNaN(end)) {
            errorMessage.textContent = 'Please enter valid start and end numbers.';
            errorMessage.style.display = 'block';
            return;
        }

        // Swap if start is greater than end
        if (start > end) {
            [start, end] = [end, start];
            startInput.value = start;
            endInput.value = end;
        }

        // Check range limit
        if (end - start + 1 > MAX_RANGE) {
            errorMessage.textContent = `Range is too large. Please keep it under ${MAX_RANGE} numbers.`;
            errorMessage.style.display = 'block';
            return;
        }

        // Generate table rows
        let tableHTML = '';
        for (let i = start; i <= end; i++) {
            const square = i * i;
            const sqrt = Math.sqrt(i).toFixed(4);
            const cube = i * i * i;
            const cbrt = Math.cbrt(i).toFixed(4);

            tableHTML += `
                <tr>
                    <td>${i}</td>
                    <td>${square}</td>
                    <td>${sqrt}</td>
                    <td>${cube}</td>
                    <td>${cbrt}</td>
                </tr>
            `;
        }
        resultsTbody.innerHTML = tableHTML;
    };

    startInput.addEventListener('input', calculateRange);
    endInput.addEventListener('input', calculateRange);

    // Initial calculation on page load
    calculateRange();
});