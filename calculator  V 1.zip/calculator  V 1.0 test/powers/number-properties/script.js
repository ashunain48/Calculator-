document.addEventListener('DOMContentLoaded', () => {
    const startInput = document.getElementById('start-number');
    const endInput = document.getElementById('end-number');
    const resultsArea = document.getElementById('results-area');
    const errorMessage = document.getElementById('error-message');

    const MAX_RANGE = 1000; // Limit range for performance

    // --- Helper Functions ---
    const isPrime = num => {
        if (num <= 1) return false;
        for (let i = 2; i * i <= num; i++) {
            if (num % i === 0) return false;
        }
        return true;
    };
    
    // Greatest Common Divisor
    const gcd = (a, b) => {
        while (b) {
            [a, b] = [b, a % b];
        }
        return a;
    };

    const findProperties = () => {
        let start = parseInt(startInput.value);
        let end = parseInt(endInput.value);

        // --- Input Validation ---
        errorMessage.style.display = 'none';
        resultsArea.innerHTML = '';
        if (isNaN(start) || isNaN(end)) {
            errorMessage.textContent = 'Please enter valid numbers.';
            errorMessage.style.display = 'block';
            return;
        }
        if (start > end) {
            [start, end] = [end, start];
            startInput.value = start;
            endInput.value = end;
        }
        if (end - start + 1 > MAX_RANGE) {
            errorMessage.textContent = `Range is too large. Max range is ${MAX_RANGE} numbers.`;
            errorMessage.style.display = 'block';
            return;
        }
        
        // --- Number Analysis ---
        let numbers = [];
        for (let i = start; i <= end; i++) {
            numbers.push(i);
        }

        const evens = numbers.filter(n => n % 2 === 0);
        const odds = numbers.filter(n => n % 2 !== 0);
        const primes = numbers.filter(isPrime);
        const naturals = numbers.filter(n => n > 0 && Number.isInteger(n));
        const wholes = numbers.filter(n => n >= 0 && Number.isInteger(n));
        
        // Co-prime is a relationship between two numbers. We'll find all co-prime pairs in the range.
        const coPrimes = [];
        if(numbers.length <= 100){ // Limit this calculation as it can be slow
            for(let i = 0; i < numbers.length; i++) {
                for(let j = i + 1; j < numbers.length; j++) {
                    if (gcd(numbers[i], numbers[j]) === 1) {
                        coPrimes.push(`(${numbers[i]}, ${numbers[j]})`);
                    }
                }
            }
        } else {
             coPrimes.push('Range too large to find co-prime pairs.');
        }


        // --- Display Results ---
        let html = '';
        const createCategory = (title, data) => {
            html += `
                <div class="result-category">
                    <h3>${title} (Total: ${data.length})</h3>
                    <p>${data.length > 0 ? data.join(', ') : 'None'}</p>
                </div>
            `;
        };

        createCategory('Total Numbers in Range', numbers);
        createCategory('Even Numbers', evens);
        createCategory('Odd Numbers', odds);
        createCategory('Prime Numbers', primes);
        createCategory('Natural Numbers', naturals);
        createCategory('Whole Numbers', wholes);
        createCategory('Co-Prime Pairs', coPrimes);

        resultsArea.innerHTML = html;
    };

    startInput.addEventListener('input', findProperties);
    endInput.addEventListener('input', findProperties);

    // Initial calculation on page load
    findProperties();
});