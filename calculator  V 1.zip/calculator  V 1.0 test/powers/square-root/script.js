document.addEventListener('DOMContentLoaded', () => {
    const numberInput = document.getElementById('number-input');
    const resultValue = document.getElementById('result-value');

    function calculateSquareRoot() {
        const inputValue = numberInput.value;

        // If the input is empty, reset the result display
        if (inputValue.trim() === '') {
            resultValue.textContent = '-';
            return;
        }

        const number = parseFloat(inputValue);

        // Check if the parsed value is a valid number
        if (isNaN(number)) {
            resultValue.textContent = 'Invalid Input';
            return;
        }

        // Square root is not defined for negative numbers in real numbers
        if (number < 0) {
            resultValue.textContent = 'Cannot be negative';
            return;
        }

        // Calculate the square root
        const squareRoot = Math.sqrt(number);

        // Display the result, formatted with commas for readability
        resultValue.textContent = squareRoot.toLocaleString();
    }

    // Add an event listener to the input field to calculate on every change
    numberInput.addEventListener('input', calculateSquareRoot);

    // Initial calculation to set the correct state on page load
    calculateSquareRoot();
});