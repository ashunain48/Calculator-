document.addEventListener('DOMContentLoaded', () => {
    const numberInput = document.getElementById('number-input');
    const limitInput = document.getElementById('limit-input');
    const resultsContainer = document.getElementById('results-container');

    const generateTable = () => {
        const number = parseInt(numberInput.value);
        const limit = parseInt(limitInput.value);

        // Clear previous results
        resultsContainer.innerHTML = '';

        if (isNaN(number) || isNaN(limit)) {
            resultsContainer.innerHTML = '<p>Please enter valid numbers.</p>';
            return;
        }
        
        if (limit > 200) {
            resultsContainer.innerHTML = '<p>Limit cannot be greater than 200.</p>';
            return;
        }
        
        if (limit < 1) {
             resultsContainer.innerHTML = '<p>Limit must be at least 1.</p>';
             return;
        }

        let tableHTML = '';
        for (let i = 1; i <= limit; i++) {
            const result = number * i;
            // Using <p> tags for better spacing and accessibility
            tableHTML += `<p>${number} &times; ${i} = ${result}</p>`;
        }
        
        resultsContainer.innerHTML = tableHTML;
    };

    // Add event listeners to both input fields
    numberInput.addEventListener('input', generateTable);
    limitInput.addEventListener('input', generateTable);

    // Generate the table on initial page load
    generateTable();
});